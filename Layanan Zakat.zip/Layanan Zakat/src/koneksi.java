
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author user
 */
public class koneksi {
    private static  Connection koneksi;
    public static Connection getKoneksi(){
    if(koneksi==null){
            try {
                String url = "jdbc:mysql://localhost/dbzakat";
                String user = "root";
                String pw = "";
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                koneksi = DriverManager.getConnection(url,user,pw);
                System.out.println("Sukses");

                 } catch (SQLException ex) {
                System.out.println("Error");;
            }
        }
    return koneksi;
    }
    
    public static void main(String args[]) {
        getKoneksi();
    }
}
